// Wie beim KI-Gateway (ai-provider.interface.ts): eine schmale Schnittstelle,
// gegen die der Rest der Anwendung programmiert. Ein Wechsel von lokalem
// Dateisystem auf S3-kompatiblen Objektspeicher (Punkt 6: "geeignetes
// Datei-/Objektspeicherkonzept") bedeutet später NUR eine neue Klasse, die
// dieses Interface implementiert, plus eine Zeile im Modul (FILE_STORAGE-Token).
export interface StoredFile {
  storagePath: string; // interner Verweis, wird in Document.storagePath abgelegt
}

export interface FileStorage {
  readonly name: string;
  save(companyId: string, originalName: string, content: Buffer): Promise<StoredFile>;
  read(storagePath: string): Promise<Buffer>;
}

export const FILE_STORAGE = Symbol('FILE_STORAGE');
